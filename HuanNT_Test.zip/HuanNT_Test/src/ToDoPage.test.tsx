import React from 'react';
import ReactDOM from 'react-dom';
import ToDoPage from './ToDoPage';

it('renders without crashing', () => {
    const div = document.createElement('div');
    // ReactDOM.render(<ToDoPage history />, div);
});